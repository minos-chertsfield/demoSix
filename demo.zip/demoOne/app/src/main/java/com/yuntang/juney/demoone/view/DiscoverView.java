package com.yuntang.juney.demoone.view;

import com.yuntang.juney.demoone.adapter.MusicAdapter;
import com.yuntang.juney.demoone.bean.MusicInfo;

import java.util.List;

/**
 * Created by admini
 * on 2019/7/23
 */
public interface DiscoverView {


    void onSuccess(String json);

}

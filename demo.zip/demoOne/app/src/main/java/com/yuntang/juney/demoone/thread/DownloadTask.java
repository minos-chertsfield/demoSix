package com.yuntang.juney.demoone.thread;

import android.os.AsyncTask;

/**
 * Created by admini
 * on 2019/7/23
 */
public class DownloadTask extends AsyncTask {

    @Override
    protected Object doInBackground(Object[] objects) {
        return null;
    }
}

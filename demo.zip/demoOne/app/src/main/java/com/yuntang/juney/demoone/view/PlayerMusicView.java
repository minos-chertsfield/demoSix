package com.yuntang.juney.demoone.view;

/**
 * Created by admini
 * on 2019/7/17
 */
public interface PlayerMusicView {    //音乐播放器视图接口



}

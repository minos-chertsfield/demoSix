package com.yuntang.juney.demoone;

/**
 * Created by admini
 * on 2019/7/11
 */
public class Reception {   //接收服务器返回数据的类

}

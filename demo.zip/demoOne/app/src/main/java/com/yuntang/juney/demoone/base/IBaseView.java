package com.yuntang.juney.demoone.base;

/**
 * Created by admini
 * on 2019/7/11
 */
public interface IBaseView {
}

package com.yuntang.juney.demoone.presenter;

import com.yuntang.juney.demoone.contract.demoContract;

/**
 * Created by admini
 * on 2019/7/11
 */
public class demoPresenter implements demoContract.Presenter {

}

package com.yuntang.juney.demoone.view;

/**
 * Created by admini
 * on 2019/7/13
 */
public interface MainView {    //主页功能接口



}

package com.yuntang.juney.demoone.bean;

/**
 * Created by admini
 * on 2019/7/12
 */
public class VideoInfo {   //视频信息类


}

package com.yuntang.juney.demoone.contract;

/**
 * Created by admini
 * on 2019/7/11
 */
public interface demoContract {     //契约类
    interface Model {     //model接口

    }

    interface View {      //view接口

    }

    interface Presenter {     //presenter接口

    }
}
